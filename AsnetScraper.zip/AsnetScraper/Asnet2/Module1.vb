﻿Imports System.Text.RegularExpressions

Module Module1
    Sub setStatus(ByVal status As String)
        frmMain.lblStatusBar.Text = status
    End Sub
End Module
